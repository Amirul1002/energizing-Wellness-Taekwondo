<?php 

require '../../dbh.class.php';
require 'classes/5.1_attendance_report.model.class.php';
require "classes/5.1_attendance_report.view.class.php";

$display_attendence_report_func = new ATTENDENCE_REPORT_VIEW();


?>