<?php
class CLASS_DISPLAY_VIEW extends CLASS_DISPLAY_MODEL{
     //CLASS (CLASS_DISPLAY_MODEL)-->(CLASS_DISPLAY_VIEW) FUNC DISPLAY (VECLASSNDOR)
    public function v_display_class($today){
        $this->m_display_class($today);
    }
}
?>