<?php
class ATTENDENCE_REPORT_VIEW extends ATTENDENCE_REPORT_MODEL{

    //CLASS (ORDER_MANAGEMENT_MODEL)-->(ORDER_MANAGEMENT_VIEW) FUNC DISPLAY (FOOD MENU)
   public function v_display_attendence_report_func(){
       $this->m_display_attendence_report_func();
   }
}
?>